package com.teja.assignment3;


public class BankAccountServiceImpl implements BankAccountService {

	public double withdraw(long accountId, double balance) {
		// TODO Auto-generated method stub
		return 0;
	}

	public double deposit(long accountId, double balance) {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getBalance(long accountId) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean fundTransfer(long fromAccount, long toAccount, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

}