package com.teja.assignment3;
public class BankAccountRepositoryImpl implements BankAccountRepository {

	public double getBalance(long accountId) {
		// TODO Auto-generated method stub
		return 0;
	}

	public double updateBalance(long accountId, double newBalance) {
		// TODO Auto-generated method stub
		return 0;
	}

}
