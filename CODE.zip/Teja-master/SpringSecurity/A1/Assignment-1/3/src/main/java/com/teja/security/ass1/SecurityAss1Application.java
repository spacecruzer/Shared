package com.teja.security.ass1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityAss1Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityAss1Application.class, args);
	}

}
