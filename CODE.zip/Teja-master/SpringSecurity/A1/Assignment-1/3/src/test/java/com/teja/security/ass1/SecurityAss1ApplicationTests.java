package com.teja.security.ass1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityAss1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
