package com.teja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class bootstartup {

	public static void main(String[] args) {
	SpringApplication.run(bootstartup.class, args);

	}

}
