package com.teja.springrestass;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestassApplication2 {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestassApplication2.class, args);
	}

}
