package com.teja.springrestass;

import org.springframework.data.repository.CrudRepository;


public interface Crudrepo extends CrudRepository<customer, String>{

}
