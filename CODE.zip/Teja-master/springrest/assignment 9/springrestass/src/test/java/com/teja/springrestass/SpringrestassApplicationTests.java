package com.teja.springrestass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringrestassApplicationTests {

	@Test
	void contextLoads() {
	}

}
