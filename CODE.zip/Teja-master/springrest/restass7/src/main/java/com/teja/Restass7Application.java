package com.teja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restass7Application {

	public static void main(String[] args) {
		SpringApplication.run(Restass7Application.class, args);
	}

}
