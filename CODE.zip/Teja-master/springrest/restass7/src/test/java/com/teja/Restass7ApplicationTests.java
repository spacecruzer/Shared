package com.teja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Restass7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
