package com.segu;

public class ssimpl {
	public double si(double p, double r, double t) {
		return p*t*(r/100);
	}

}
