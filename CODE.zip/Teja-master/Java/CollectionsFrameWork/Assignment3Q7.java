
class ParkingSlot {
    private String ownerName;
    private int carNumber;
    private int token;
    private int level;
    private int section;
    private int slot;
}

class Parked_CarOwenerList {
    int levels = 3;
    int sections = 4;
    int slots = 20;
    public void add_new_car(Assignment3Q7 obj){}
    public void remove_car(String name,int carNo){}
    public String get_parked_car_location(int token){}
}

public class Assignment3Q7 {
    private String name;
    private String carModel;
    private int carNo;
    private int mobileNumber;
    private String address;


    public static void main(String[] args) {}
}

